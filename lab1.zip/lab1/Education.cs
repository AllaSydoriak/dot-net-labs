using System;

namespace lab1{
    public enum Education{ Master, Bachelor, SecondEducation};    
}
