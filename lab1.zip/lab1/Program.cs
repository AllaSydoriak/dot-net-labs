﻿using System;


namespace lab1
{
    

    class Program
    {
        public static int сountRows(int mult)
        {
            int rows = 0;
            int countInRow = 0;
            int sum = 0;

            while (sum < mult)
            {
                countInRow += 1;
                sum += countInRow;
                rows++;
            }
            return rows;
        }

        static void Main(string[] args)
        {

            Student ob = new Student();

            Exam ex = new Exam();

            ob.AddExams(ex);
            ob.AddExams(ex);

            Test test = new Test();
            
            ob.AddTests(test);

        
            ob.Group = 800;

            
            Console.WriteLine(ob.ToString());

        

        }
    }
}
